package com.zmwh.yijingcai.manager;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.FileUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.google.gson.Gson;
import com.zmwh.yijingcai.bean.ResponseBean;
import com.zmwh.yijingcai.bean.UpdateVersionBean;
import com.zmwh.yijingcai.parameter.UpdateVersionParameter;
import com.zmwh.yijingcai.service.DownloadTask;
import com.zmwh.yijingcai.service.UpdateVersionService;
import com.zmwh.yijingcai.utils.AESUtils;
import com.zmwh.yijingcai.utils.CommonUtil;
import com.zmwh.yijingcai.utils.Const;
import com.zmwh.yijingcai.utils.RequestUtils;
import com.zmwh.yijingcai.view.dialog.ContentDialog;
import com.zmwh.yijingcai.view.dialog.OneButtonDialog;

import java.io.File;

public class UpdateCheckManager {

    private boolean mHasTips;
    private Context mContext;

    private static UpdateCheckManager sManager = new UpdateCheckManager();

    private UpdateCheckManager() {
    }

    public static UpdateCheckManager getInstance() {
        return sManager;
    }

    /**
     * 检查更新
     * @param context 上下文
     * @param imei imei码
     * @param hasTips 是否有提示
     */
    public void checkUpdate(final Context context, String imei, boolean hasTips) {
        mContext = context;
        mHasTips = hasTips;

        String hotUpdateName = SPUtils.getInstance().getString(Const.HOT_UPDATE_NAME);
        UpdateVersionParameter updateVersionParameter = new UpdateVersionParameter(hotUpdateName);

        new RequestUtils(mContext, imei, 0, updateVersionParameter, true) {
            @Override
            public void onResponse(ResponseBean responseBean, int id) {
                if (responseBean.getCode() == 1) {
                    String responseJson = AESUtils.decrypt(responseBean.getResult().getBytes());
                    final UpdateVersionBean updateVersionBean = new Gson().fromJson(responseJson, UpdateVersionBean.class);
                    // 热更新
                    final String upgradeUrl = updateVersionBean.getUpgradeUrl();
                    final int hotOrVersion = updateVersionBean.getHotOrVersion();
                    final boolean isMandatoryUpdate = updateVersionBean.isMandatoryUpdate();
                    // 有apk包
                    if (upgradeUrl.contains(".apk")) {
                        String fileName = upgradeUrl.substring(upgradeUrl.lastIndexOf("/") + 1);
                        final String path = Environment.getExternalStorageDirectory().getAbsolutePath()
                                + File.separator + AppUtils.getAppPackageName()
                                + File.separator + "Download"
                                + File.separator + AppUtils.getAppName() + fileName;
                        if (1 == hotOrVersion) {
                            if (!FileUtils.isFileExists(path)) {
                                Intent intent = new Intent(mContext, UpdateVersionService.class);
                                intent.putExtra("type", hotOrVersion);
                                intent.putExtra("url", upgradeUrl);
                                intent.putExtra("isMandatoryUpdate", isMandatoryUpdate);
                                mContext.startService(intent);
                                LogUtils.eTag("ha", "准备跳转到UpdateVersionService下载更新");
                            }

                        } else if (2 == hotOrVersion) {
                            if (isMandatoryUpdate) {
                                // 强制更新
                                OneButtonDialog dialog = new OneButtonDialog(mContext);
                                dialog.show();
                                dialog.setCanceledOnTouchOutside(false);
                                dialog.setTitle("");
                                dialog.setContent("有新版本更新，点击立即更新！");
                                dialog.setDetermineText("立即更新");
                                dialog.setCancelable(false);
                                dialog.setDialogResultListener(new OneButtonDialog.OnResultListener() {
                                    @Override
                                    public void getResult() {
                                        if (FileUtils.isFileExists(path)) {
                                            CommonUtil.installAPK(mContext, FileUtils.getFileByPath(path));
                                        } else {
                                            // 下载更新包
                                            new DownloadTask(mContext, upgradeUrl);
                                        }
                                    }
                                });

                            } else {
                                // 版本更新
                                final ContentDialog dialog = new ContentDialog(mContext);
                                dialog.show();
                                dialog.setDialogTitle("应用更新");
                                dialog.setDialogContent("有新版本更新，是否安装更新？");
                                dialog.setDialogDetermineText("更新");
                                dialog.setCanceledOnTouchOutside(false);
                                dialog.setContentDialogResultListener(new ContentDialog.OnResultListener() {
                                    @Override
                                    public void getResult(int resultCode) {
                                        if (1 == resultCode) {
                                            if (FileUtils.isFileExists(path)) {
                                                CommonUtil.installAPK(mContext, FileUtils.getFileByPath(path));
                                            } else {
                                                // 下载更新包
                                                new DownloadTask(mContext, upgradeUrl);
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    } else {
                        if (mHasTips)
                            ToastUtils.showShort("已是最新版本");
                    }
                } else {
                    ToastUtils.showShort(responseBean.getResult());
                }
            }
        };

    }


}

package com.zmwh.yijingcai.manager;

import com.blankj.utilcode.util.LogUtils;
import com.zmwh.yijingcai.bean.Prize;
import com.zmwh.yijingcai.bean.PrizeForecast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * 彩金优化管理类
 */
public class PrizeForecastManager {

    private List<PrizeForecast> units;
    private Prize prize;


    public PrizeForecastManager(List<PrizeForecast> units) {
        this.units = units;
        prize = new Prize();
    }

    public Prize calculatePassWays(String[] passWays) {

//        Prize prize = new Prize();

        if (passWays == null || passWays.length == 0) {
            return prize;
        }

        float lastMin = Float.MAX_VALUE;
        float lastMax = 0;

        for (int i = 0; i < passWays.length; i++) {
            String pw = passWays[i];
            prize = calculateOnePassWay(pw);
            if (prize.getMin() < lastMin) {
                lastMin = prize.getMin();
            }
            lastMax += prize.getMax();
        }

        //乘以每注彩米2米
        lastMin *= 2;
        lastMax *= 2;
        BigDecimal minValue = new BigDecimal(lastMin).setScale(2, RoundingMode.HALF_UP);
        BigDecimal maxValue = new BigDecimal(lastMax).setScale(2, RoundingMode.HALF_UP);

        prize.setMin(minValue.floatValue());
        prize.setMax(maxValue.floatValue());
        return prize;
    }


    private Prize calculateOnePassWay(String passWay) {
        if (this.units == null || this.units.size() == 0 || passWay.equals("")) {
            return prize;
        }

        //单关
        if (passWay.length() == 0 || passWay.equals("单关")) {
            float min = Float.MAX_VALUE;
            float max = 0;


            for (int i = 0; i < this.units.size(); i++) {
                PrizeForecast pf = this.units.get(i);
                if (pf.getMin() < min) {
                    min = pf.getMin();
                }
                max += pf.getMax();
            }
            return new Prize(min, max);
        }

        //过关 n串m
        String[] passWays = passWay.split("串");
        if (passWays.length < 1) {
            LogUtils.eTag("prize", "过关方式有问题");
            return null;
        }

        int n = Integer.valueOf(passWays[0]);
        int m = Integer.valueOf(passWays[1]);

        //自由过关（串一）
        if (m == 1) {
            /** 是否有设胆 */
            boolean hasDan = false;
            int danCount = 0;
            float danValue_min = 1;
            float danValue_max = 1;

            List<PrizeForecast> units = this.units;//备份

            for (int i = 0; i < this.units.size(); i++) {
                PrizeForecast pf = this.units.get(i);
                if (pf.isDan()) {
                    danValue_min *= pf.getMin();
                    danValue_max *= pf.getMax();
                    hasDan = true;
                    danCount++;
                    units.remove(pf);
                }
            }
            if (hasDan) {
                /** 重新计算串关次数 */
                int newN = n - danCount;
                Prize temp = calculateFreeWay(units, newN);
                float min = temp.getMin();
                float max = temp.getMax();
                min *= danValue_min;
                max *= danValue_max;
                temp.setMin(min);
                temp.setMax(max);
                return temp;
            } else {
                return calculateFreeWay(units, n);
            }
        }//组合过关（串多）
        else if (m > 1) {
            return calculateComWay(units, passWay);
        }

        return prize;

    }


    /**
     * 计算自由过关 n串1
     * @param units
     * @param n
     * @return
     */
    private Prize calculateFreeWay(List<PrizeForecast> units, int n) {
        float min = Float.MAX_VALUE;
        float max = 0;
        Prize result = new Prize(min, max);
//        Prize result = Prize.init(min, max);
        p_calculateFreeWay(units, 0, units.size() - n, n, 1, 1, result);
        return result;
    }


    /**
     * 计算自由过关 n串1的详细方法
     * @param units
     * @param start
     * @param end
     * @param loop
     * @param minValue
     * @param maxValue
     * @param result
     */
    private void p_calculateFreeWay(List<PrizeForecast> units, int start, int end, int loop,
                                    float minValue, float maxValue, Prize result) {
        float minResult;
        float maxResult;
        if (loop <= 1) {
            for (int i = start; i <= end; i++) {
                PrizeForecast pf = units.get(i);
                minResult = minValue * pf.getMin();
                maxResult = maxValue * pf.getMax();

                if (result.getMin() > minResult) {
                    result.setMin(minResult);
//                    result.min = minResult;
                }
                float max = result.getMax();
                max += maxResult;
                result.setMax(max);
//                result.max += maxResult;
            }
        } else {
            for (int i = start; i <= end; i++) {
                PrizeForecast pf = units.get(i);
                float min = pf.getMin();
                float max = pf.getMax();
                minResult = minValue * min;
                maxResult = maxValue * max;
                p_calculateFreeWay(units, i + 1, end + 1, loop - 1, minResult, maxResult, result);
            }
        }
    }


    private Prize calculateComWay(List<PrizeForecast> units, String passWay) {
//        Prize result = new Prize();
        int value = J_com_passValueWithPassWay(passWay);//过关方式的拆分的值

        //n串m
        String[] pwArr = passWay.split("串");
        int n = Integer.valueOf(pwArr[0]);

        float lastMin = Float.MAX_VALUE;
        float lastMax = 0;
        Prize temp;
        for (int i = 2; i <= n; i++) {
            if ((1 << i & value) > 0) {
                temp = calculateFreeWay(units, i);
                if (temp.getMin() < lastMin) {
                    lastMin = temp.getMin();
                }
                lastMax += temp.getMax();
            }
        }

//        return Prize().init(lastMin, lastMax);
        return new Prize(lastMin, lastMax);
    }


    private int J_com_passValueWithPassWay(String passWay) {

        int value = 0;
        String[] pwArr = passWay.split("串");
        int n = Integer.valueOf(pwArr[0]);
        int m = Integer.valueOf(pwArr[1]);

        //分解 n串m 为 n串1 的组合（参考竞彩过关表）
        switch (n) {
            case 3: {
                switch (m) {
                    case 3:
                        value = 1 << 2;   // 100 = 4
                        break;
                    case 4:
                        value = 1 << 2 | 1 << 3;  // 100|1000 = 1100 = 12
                        break;
                    default:
                        break;
                }
            }
            break;

            case 4: {
                switch (m) {
                    case 4:
                        value = 1 << 3;
                        break;
                    case 5:
                        value = 1 << 3 | 1 << 4;
                        break;
                    case 6:
                        value = 1 << 2;
                        break;
                    case 11:
                        value = 1 << 2 | 1 << 3 | 1 << 4;
                        break;
                    default:
                        break;
                }
            }
            break;

            case 5: {
                switch (m) {
                    case 5:
                        value = 1 << 4;
                        break;
                    case 6:
                        value = 1 << 4 | 1 << 5;
                        break;
                    case 10:
                        value = 1 << 2;
                        break;
                    case 16:
                        value = 1 << 3 | 1 << 4 | 1 << 5;
                        break;
                    case 20:
                        value = 1 << 2 | 1 << 3;
                        break;
                    case 26:
                        value = 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5;
                        break;
                    default:
                        break;
                }
            }
            break;

            case 6: {
                switch (m) {
                    case 6:
                        value = 1 << 5;
                        break;
                    case 7:
                        value = 1 << 5 | 1 << 6;
                        break;
                    case 15:
                        value = 1 << 2;
                        break;
                    case 20:
                        value = 1 << 3;
                        break;
                    case 22:
                        value = 1 << 4 | 1 << 5 | 1 << 6;
                        break;
                    case 35:
                        value = 1 << 2 | 1 << 3;
                        break;
                    case 42:
                        value = 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6;
                        break;
                    case 50:
                        value = 1 << 2 | 1 << 3 | 1 << 4;
                        break;
                    case 57:
                        value = 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6;
                        break;
                    default:
                        break;
                }
            }
            break;

            case 7: {
                switch (m) {
                    case 7:
                        value = 1 << 6;
                        break;
                    case 8:
                        value = 1 << 6 | 1 << 7;
                        break;
                    case 21:
                        value = 1 << 5;
                        break;
                    case 35:
                        value = 1 << 4;
                        break;
                    case 120:
                        value = 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7;
                        break;
                    default:
                        break;
                }
            }
            break;

            case 8: {
                switch (m) {
                    case 8:
                        value = 1 << 7;
                        break;
                    case 9:
                        value = 1 << 7 | 1 << 8;
                        break;
                    case 28:
                        value = 1 << 6;
                        break;
                    case 56:
                        value = 1 << 5;
                        break;
                    case 70:
                        value = 1 << 4;
                        break;
                    case 247:
                        value = 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7 | 1 << 8;
                        break;
                    default:
                        break;
                }
            }
            break;
        }

        return value;
    }


}

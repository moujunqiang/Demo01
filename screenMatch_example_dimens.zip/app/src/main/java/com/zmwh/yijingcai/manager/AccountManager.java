package com.zmwh.yijingcai.manager;

import android.content.Context;

import com.blankj.utilcode.util.SPUtils;
import com.google.gson.Gson;
import com.zmwh.yijingcai.bean.ResponseBean;
import com.zmwh.yijingcai.bean.mine.LoginBean;
import com.zmwh.yijingcai.parameter.LoginParameter;
import com.zmwh.yijingcai.utils.AESUtils;
import com.zmwh.yijingcai.utils.CommonUtil;
import com.zmwh.yijingcai.utils.Const;
import com.zmwh.yijingcai.utils.EmptyUtils;
import com.zmwh.yijingcai.utils.RequestUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class AccountManager {

    private static AccountManager sManager = new AccountManager();

    private AccountManager(){}

    public static AccountManager getInstance(){
        return sManager;
    }



    public void autoLogin(Context context, String imei){

        String userName = SPUtils.getInstance().getString(Const.USER_NAME);
        String password = SPUtils.getInstance().getString(Const.UserPassWord);

        if (EmptyUtils.isNotEmpty(userName) && EmptyUtils.isNotEmpty(password)) {
            LoginParameter loginParameter = new LoginParameter(userName, password);
            new RequestUtils(context, imei, 2, loginParameter, false) {
                @Override
                public void onResponse(ResponseBean responseBean, int id) {
                    if (responseBean.getCode() == 1) {
                        String responseJson = AESUtils.decrypt(responseBean.getResult().getBytes());
                        LoginBean loginBean = new Gson().fromJson(responseJson, LoginBean.class);
                        SPUtils.getInstance().put(Const.USER_ID, loginBean.getUserID());
                        SPUtils.getInstance().put(Const.USER_NAME, loginBean.getUserName());
                        SPUtils.getInstance().put(Const.UserPassWord, loginBean.getUserPassWord());
                        SPUtils.getInstance().put(Const.UserPictureUrl, Const.RootURL + loginBean.getPictureUrl());
                        SPUtils.getInstance().put(Const.REALITY_NAME, loginBean.getRealityName());
                        SPUtils.getInstance().put(Const.MOBILE, loginBean.getMobile());
                        SPUtils.getInstance().put(Const.IDCARD, loginBean.getIDCard());
                        SPUtils.getInstance().put(Const.SAFETY_CODE, loginBean.getSafetycode());
                        SPUtils.getInstance().put(Const.Balance, loginBean.getBalance()
                                .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                        SPUtils.getInstance().put(Const.RedBagBalance, loginBean.getRedBagBalance()
                                .setScale(2, RoundingMode.HALF_UP).toString());
                        SPUtils.getInstance().put(Const.BanDrawingMoney, loginBean.getBanDrawingMoney()
                                .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                        SPUtils.getInstance().put(Const.Identity, loginBean.getIdentity());
                        SPUtils.getInstance().put(Const.LoginJson, responseJson);
                    }
                }
            };
        }else {
            CommonUtil.clearUserInfo();
        }
    }



}
